RAM = {}

function RAM.tick()    --what RAM Updates
end